package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.SimpleOption;

/** Lowers render distance, particles and entity distance; restores the old values on disable. */
public class OptimizationModule extends Module {
    public final NumberSetting renderDistance = add(new NumberSetting("Render dist", 8, 2, 16, 1));

    private Integer oldView;
    private Object oldParticles;
    private Double oldScale;

    public OptimizationModule() { super("Optimization", Category.MISC); }

    /** The particles option is an enum (ALL, DECREASED, MINIMAL); take the last constant without naming the type. */
    @SuppressWarnings({"unchecked", "rawtypes"})
    private static void setMinimal(SimpleOption option) {
        Object[] all = ((Enum<?>) option.getValue()).getDeclaringClass().getEnumConstants();
        option.setValue(all[all.length - 1]);
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static void restore(SimpleOption option, Object value) { option.setValue(value); }

    @Override
    protected void onEnable() {
        GameOptions o = MinecraftClient.getInstance().options;
        oldView = o.getViewDistance().getValue();
        oldParticles = o.getParticles().getValue();
        oldScale = o.getEntityDistanceScaling().getValue();
        setMinimal(o.getParticles());
        o.getEntityDistanceScaling().setValue(0.5);
        o.getViewDistance().setValue((int) renderDistance.get());
    }

    @Override
    public void onTick(MinecraftClient c) {
        int want = (int) renderDistance.get();
        if (c.options.getViewDistance().getValue().intValue() != want) c.options.getViewDistance().setValue(want);
    }

    @Override
    protected void onDisable() {
        GameOptions o = MinecraftClient.getInstance().options;
        if (oldView != null) o.getViewDistance().setValue(oldView);
        if (oldParticles != null) restore(o.getParticles(), oldParticles);
        if (oldScale != null) o.getEntityDistanceScaling().setValue(oldScale);
    }
}
