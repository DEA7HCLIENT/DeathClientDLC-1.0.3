package dev.deathclient.dlc;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.gui.screen.TitleScreen;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class DeathClientDLC implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // 1.21.9+: KeyBinding requires a Category.
        KeyBinding.Category category = KeyBinding.Category.create(Identifier.of("deathclientdlc", "main"));
        KeyBinding open = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.deathclientdlc.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, category));

        // Replace the vanilla title screen (exact class check, so our own screen is never replaced).
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen.getClass() == TitleScreen.class) client.setScreen(new MainMenuScreen());
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (open.wasPressed()) client.setScreen(new ClickGuiScreen());
            ModuleManager.tick(client);
        });
    }
}
