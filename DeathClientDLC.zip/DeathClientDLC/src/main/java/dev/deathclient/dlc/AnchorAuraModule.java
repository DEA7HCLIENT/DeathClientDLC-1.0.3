package dev.deathclient.dlc;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * Places a Respawn Anchor near the nearest player, charges it with glowstone and detonates it.
 * Works outside the Nether only. Skips anchors closer than MIN_SELF_DIST to you.
 */
public class AnchorAuraModule extends Module {
    private static final double MIN_SELF_DIST = 3.0;

    public final NumberSetting targetRange = add(new NumberSetting("Target range", 10, 4, 20, 1));
    public final NumberSetting range = add(new NumberSetting("Range", 4.5, 2, 6, 0.5));
    public final NumberSetting delay = add(new NumberSetting("Delay", 3, 1, 10, 1));

    private int ticks;

    public AnchorAuraModule() { super("Anchor Aura", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient c) {
        if (++ticks < (int) delay.get()) return;
        ticks = 0;
        if (c.world.getRegistryKey() == World.NETHER) return;
        ClientPlayerEntity p = c.player;
        PlayerEntity target = Util.nearestPlayer(c, targetRange.get());
        if (target == null) return;

        BlockPos tp = target.getBlockPos();
        for (int x = -3; x <= 3; x++) for (int y = -3; y <= 3; y++) for (int z = -3; z <= 3; z++) {
            BlockPos b = tp.add(x, y, z);
            BlockState st = c.world.getBlockState(b);
            if (!st.isOf(Blocks.RESPAWN_ANCHOR)) continue;
            if (p.getEyePos().distanceTo(Vec3d.ofCenter(b)) > range.get()) continue;
            if (Util.pos(p).distanceTo(Vec3d.ofCenter(b)) < MIN_SELF_DIST) continue;
            if (st.get(RespawnAnchorBlock.CHARGES) == 0) {
                int slot = Util.findHotbar(p, Items.GLOWSTONE);
                if (slot < 0) return;
                p.getInventory().setSelectedSlot(slot);
            } else if (p.getMainHandStack().isOf(Items.GLOWSTONE)) {
                // Glowstone in hand would only add charge; hold something else to detonate.
                p.getInventory().setSelectedSlot((p.getInventory().getSelectedSlot() + 1) % 9);
            }
            click(c, p, b, Direction.UP);
            return;
        }
        placeAnchor(c, p, tp);
    }

    private void placeAnchor(MinecraftClient c, ClientPlayerEntity p, BlockPos tp) {
        int slot = Util.findHotbar(p, Items.RESPAWN_ANCHOR);
        if (slot < 0) return;
        BlockPos[] candidates = {
                tp.up(2), tp.up().north(), tp.up().south(), tp.up().east(), tp.up().west()
        };
        for (BlockPos pos : candidates) {
            if (!c.world.getBlockState(pos).isAir()) continue;
            if (p.getEyePos().distanceTo(Vec3d.ofCenter(pos)) > range.get()) continue;
            if (Util.pos(p).distanceTo(Vec3d.ofCenter(pos)) < MIN_SELF_DIST) continue;
            for (Direction dir : Direction.values()) {
                BlockPos neighbor = pos.offset(dir);
                if (!c.world.getBlockState(neighbor).isSolidBlock(c.world, neighbor)) continue;
                p.getInventory().setSelectedSlot(slot);
                click(c, p, neighbor, dir.getOpposite());
                return;
            }
        }
    }

    private void click(MinecraftClient c, ClientPlayerEntity p, BlockPos pos, Direction side) {
        Vec3d hitPos = Vec3d.ofCenter(pos).add(Vec3d.of(side.getVector()).multiply(0.5));
        c.interactionManager.interactBlock(p, Hand.MAIN_HAND, new BlockHitResult(hitPos, side, pos, false));
        p.swingHand(Hand.MAIN_HAND);
    }
}
